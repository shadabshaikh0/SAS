<!DOCTYPE html>
<html>
<head></head>
    <body>
        <center><h1> Student Information </h1></center>
        <form action="store.php" method="POST" >
            Name:<br>
            <input type="text" name="name" /><br><br>
            Roll No:<br>
            <input type="number" name="rollno" /><br><br>

            <!-- <button type="submit">Submit</button> -->
            <input type="submit" value ="Submit"/>
        </form>
        
    </body>
</html>