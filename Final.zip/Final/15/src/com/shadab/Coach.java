package com.shadab;

public interface Coach {
	public String getDailyWorkout();
}
