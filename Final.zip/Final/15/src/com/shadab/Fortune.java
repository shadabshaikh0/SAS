package com.shadab;

public interface Fortune {
	public String getDailyFortune();
}
